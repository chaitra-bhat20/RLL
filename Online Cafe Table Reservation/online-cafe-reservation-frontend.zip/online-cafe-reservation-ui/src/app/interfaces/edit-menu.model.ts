export interface EditMenu {
    itemId: number;
    itemName: string;
    description: string;
    price: number;
    availability: boolean;
    type: string;
    enable: boolean;
}
